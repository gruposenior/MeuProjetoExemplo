package demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController


@RequestMapping(value = "/teste")
public class TesteController {
	
	@RequestMapping(value = "hello",method=RequestMethod.GET)
	public String sayHello(){
		return "Bem vindo a Escola de TI 2015";
	}
	
	@RequestMapping(value = "/alunos/{ra}",method=RequestMethod.GET)
	public Aluno getAluno(@PathVariable Integer ra){
		Aluno novo = new Aluno("Vinicius",1);
		return novo;
		
	}
	
	@RequestMapping(value = "/inserirAluno", method=RequestMethod.POST)
	public String criarAluno(@RequestBody(required = true) Aluno novo){
		return "Aluno de nome "+ novo.getNome() + "recebido com imenso sucesso";
	}
	
	
	

}
